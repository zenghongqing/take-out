<template>
  <div class="cross-line"></div>
</template>
<script>
export default {
  components: {},
  data () {
    return {}
  },
  props: {},
  watch: {},
  methods: {},
  filters: {},
  computed: {},
  created () {},
  mounted () {},
  destroyed () {}
}
</script>
<style lang="scss" scoped>
  .cross-line {
    height: 16px;
    width: 100%;
    background: #ebebeb;
  }
</style>
